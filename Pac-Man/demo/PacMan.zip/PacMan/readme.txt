
DEZIPPEZ dans un dossier et lancez :
PacMan.exe pour jouer
Tableaux.exe pour cr�er ou remplacer des tableaux

Le jeu :
--------
Entrer pour Pause ou d�marrer.
Les fl�ches pour ce deplacer.
Echap pour Quitter.
Clic droit sur le nombre de fant�mes pour le changer de 1 � 3
Clic droit sur le Niveau en pause pour changer de niveau mais c'est de la triche ;-)
Une option cach�e pour vous rendre invisible en faisant...


Les bonus :
-----------
- les clefs emprisonnent tous les fantomes
- l'�toile vous donne 2000 pts
- le coeur vous donne une vie en plus
- le flacon vous rend invisible
- le marteau vous permet de casser les murs


Enjoy !

Fabrice
<fabrice.labrouche@free.fr>

=============================================================================================================
Les dessins 3D ont �t� r�alis�s par une autre personne qui me l'es a envoy�s. 
Je l'en remercie vivement, mais h�las je n'ai plus son nom. Si elle se reconnait...
=============================================================================================================
